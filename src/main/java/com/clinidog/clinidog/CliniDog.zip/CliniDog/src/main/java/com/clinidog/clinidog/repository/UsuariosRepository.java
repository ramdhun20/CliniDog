package com.clinidog.clinidog.repository;


import com.clinidog.clinidog.model.Usuarios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuariosRepository extends JpaRepository<Usuarios, Long> {

    boolean existsByEmail(String email);

    Usuarios findByEmail(String email);
}
