package com.clinidog.clinidog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CliniDogApplication {

    public static void main(String[] args) {
        SpringApplication.run(CliniDogApplication.class, args);
    }

}
