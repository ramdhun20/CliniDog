package com.clinidog.clinidog.model;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "mascota")

public class Mascota {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id")

    private Usuarios usuarios;

    private String nombre;
    private String raza;
    private Integer edad;
    private Integer propiestario;
    private String vacunas;

    @Column(name = "fecha_registro")
    private Date fechaRegistro;

    public Long getId() {
        return id;
    }

    public Usuarios getUsuarios() {
        return usuarios;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRaza() {
        return raza;
    }

    public Integer getEdad() {
        return edad;
    }

    public Integer getPropiestario() {
        return propiestario;
    }

    public String getVacunas() {
        return vacunas;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }
}
