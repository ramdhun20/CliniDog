package com.clinidog.clinidog.controller;

import com.clinidog.clinidog.model.Usuarios;

import com.clinidog.clinidog.repository.UsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UsuariosRepository usuariosRepository;

    @PostMapping("/usuario")
    public Usuarios loginUsuario(@RequestBody Usuarios usuarios){
        Usuarios usuarioExistente = usuariosRepository.findByEmail(usuarios.getEmail());
        if (usuarioExistente != null && usuarioExistente.getContrasena().equals(usuarios.getContrasena())) {
            return usuarioExistente;
        } else {
            return null;
        }
    }
}
